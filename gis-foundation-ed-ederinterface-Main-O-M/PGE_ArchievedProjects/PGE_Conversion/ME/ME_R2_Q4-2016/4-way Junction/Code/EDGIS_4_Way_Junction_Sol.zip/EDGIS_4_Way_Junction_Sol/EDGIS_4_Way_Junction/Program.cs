using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using ESRI.ArcGIS;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.NetworkAnalysis;
using Miner.Interop;

namespace EDGIS_4_Way_Junction
{
    class Program
    {
        #region private static variables
        private static LicenseInitializer m_AOLicenseInitializer = new EDGIS_4_Way_Junction.LicenseInitializer();
        private static IWorkspace workspace = default(IWorkspace);
        private static string sPath = (String.IsNullOrEmpty(ConfigurationManager.AppSettings["LOGPATH"]) ? System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) : ConfigurationManager.AppSettings["LOGPATH"]) + "\\Logfile_" + DateTime.Now.Ticks.ToString() + ".log";
        private static StreamWriter pSWriter = default(StreamWriter);
        private static IMMAppInitialize arcFMAppInitialize = new MMAppInitializeClass();
        private static List<decimal> objectIdsLine = default(List<decimal>);
        private static IFeatureClass pFClass_Junction = default(IFeatureClass);
        private static IFeatureClass pFClass_Tie = default(IFeatureClass);
        private static IFeatureClass pFClass_PriOHCond = default(IFeatureClass);
        private static IFeatureClass pFClass_PriUGCond = default(IFeatureClass);
        private static IFeatureClass traceFC = default(IFeatureClass);
        enum TraceDirection
        {
            Downstream = 1, Upstream = 2, Connected = 3
        }
        #endregion
        /// <summary>
        /// main method
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            #region main variables
            INetworkCollection pNWCollection = default(INetworkCollection);
            IGeometricNetwork geomNet = default(IGeometricNetwork);
            IVersion pVersion = default(IVersion);

            IFeature pFeatJunction = default(IFeature);
            IFeature pFeatTie = default(IFeature);
            IFeature pFeatLine = default(IFeature);
            IFeatureCursor pFCursorJunc = default(IFeatureCursor);
            IFeatureCursor pFCursorLine = default(IFeatureCursor);
            IQueryFilter pQFilter = default(IQueryFilter);
            ITopologicalOperator topologicalOerator = default(ITopologicalOperator);
            ISpatialFilter spatialFilter = default(ISpatialFilter);
            IEnumEIDInfo pEnumEIDInfoLine = default(IEnumEIDInfo);
            IEIDInfo pEIDInfo = default(IEIDInfo);
            ESRI.ArcGIS.Geometry.IPoint junctionPoint = default(PointClass);
            int tracecount = 0;
            int intersectcount = 0;
            int matchingLine = 0;
            int junctionCount = 0;
            string Junction_value;
            // to get trace results for tie feature
            IEnumEIDInfo pEnumEIDInfoLineTemp = default(IEnumEIDInfo);
            IEIDInfo pEIDInfoTemp = default(IEIDInfo);
            #endregion
            #region configurable values
            string JUNCTIONS_FC_NAME = ConfigurationManager.AppSettings["ELECTRICDISTNETWORK_JUNCTIONS_FC_NAME"];
            string TIE_FC_NAME = ConfigurationManager.AppSettings["TIE_FC_NAME"];
            string PRI_UG_COND_FC_NAME = ConfigurationManager.AppSettings["PRI_UG_COND_FC_NAME"];
            string PRI_OH_COND_FC_NAME = ConfigurationManager.AppSettings["PRI_OH_COND_FC_NAME"];
            string CONN_SDE_FILE = ConfigurationManager.AppSettings["CONN_SDE_FILE"];
            string SESSION_NAME = ConfigurationManager.AppSettings["SESSION_NAME"];
            string JUNCTION_LIST_CSV_PATH = ConfigurationManager.AppSettings["JUNCTION_LIST_CSV_PATH"];
            string TIE_FIELDS_LIST_CSV_PATH = ConfigurationManager.AppSettings["TIE_FIELDS_LIST_CSV_PATH"];
            string ELECTRIC_DATASET = ConfigurationManager.AppSettings["ELECTRIC_DATASET"];
            string ELECTRIC_DIST_NETWORK = ConfigurationManager.AppSettings["ELECTRIC_DIST_NETWORK"];
            string JUNCTION_SEARCH_FIELD = ConfigurationManager.AppSettings["JUNCTION_SEARCH_FIELD"];
            #endregion
            
            try
            {
                //create log file
                createLogFile();
                WriteLine("START");
                WriteLine("JUNCTION_LIST_CSV_PATH - " + JUNCTION_LIST_CSV_PATH);
                WriteLine("TIE_FIELDS_LIST_CSV_PATH - " + TIE_FIELDS_LIST_CSV_PATH);
                WriteLine("LOG_PATH - " + sPath);
                WriteLine("SDE connection file path - " + CONN_SDE_FILE);
                WriteLine("Session/version name - " + SESSION_NAME );
                WriteLine("Electric Dataset - " + ELECTRIC_DATASET);
                WriteLine("Electric Distribution Network - " + ELECTRIC_DIST_NETWORK);
                WriteLine("");
                objectIdsLine = new List<decimal>();
                WriteLine("Initializing License");
                m_AOLicenseInitializer.InitializeApplication(new esriLicenseProductCode[] { esriLicenseProductCode.esriLicenseProductCodeBasic, esriLicenseProductCode.esriLicenseProductCodeStandard, esriLicenseProductCode.esriLicenseProductCodeAdvanced },
                    new esriLicenseExtensionCode[] { });
                mmLicenseStatus licenseStatus = CheckOutLicenses(mmLicensedProductCode.mmLPArcFM);
                if (RuntimeManager.ActiveRuntime == null)
                    RuntimeManager.BindLicense(ProductCode.Desktop);
                WriteLine("Getting workspace from SDE connection file. ");
                workspace = ArcSdeWorkspaceFromFile(CONN_SDE_FILE);
                pNWCollection = ((IFeatureWorkspace)workspace).OpenFeatureDataset(ELECTRIC_DATASET) as INetworkCollection;
                geomNet = pNWCollection.get_GeometricNetworkByName(ELECTRIC_DIST_NETWORK);

                try
                {
                    pVersion = ((IVersionedWorkspace)workspace).FindVersion(SESSION_NAME);
                    WriteLine("Working on session - " + SESSION_NAME);
                }
                catch (Exception ex)
                {
                    WriteLine("ERROR: " + ex.Message);
                }
                
                
                #region open feature classes

                // from version (to be edited)
                pFClass_Junction = ((IFeatureWorkspace)pVersion).OpenFeatureClass(JUNCTIONS_FC_NAME);
                pFClass_Tie = ((IFeatureWorkspace)pVersion).OpenFeatureClass(TIE_FC_NAME);


                //from workspace (not to be edited)
                pFClass_PriUGCond = ((IFeatureWorkspace)workspace).OpenFeatureClass(PRI_UG_COND_FC_NAME);
                pFClass_PriOHCond = ((IFeatureWorkspace)workspace).OpenFeatureClass(PRI_OH_COND_FC_NAME);
                #endregion

                // start multi user workspace edit
                ((IMultiuserWorkspaceEdit)pVersion).StartMultiuserEditing(esriMultiuserEditSessionMode.esriMESMVersioned);
                WriteLine("Multiuser editing started.");
                if (JUNCTION_SEARCH_FIELD == "GLOBALID" || JUNCTION_SEARCH_FIELD == "OBJECTID")
                    WriteLine("Junction search field - " + JUNCTION_SEARCH_FIELD);
                else
                {
                    WriteLine("ERROR : JUNCTION_SEARCH_FIELD in configuration should be either GLOBALID or OBJECTID");
                    WriteLine("");
                }
                WriteLine("Reading junction list from " + JUNCTION_LIST_CSV_PATH);
                var reader = new StreamReader(File.OpenRead(@JUNCTION_LIST_CSV_PATH));
                while (!reader.EndOfStream)
                {

                    junctionCount++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    Junction_value = values[0].ToString();
                    WriteLine("");
                    WriteLine("Working on junction# " + junctionCount + " " + JUNCTION_SEARCH_FIELD + " = " + Junction_value);
                    pQFilter = new QueryFilterClass();
                    if (JUNCTION_SEARCH_FIELD == "GLOBALID")
                        pQFilter.WhereClause = "GLOBALID = '" + Junction_value + "'";
                    else if (JUNCTION_SEARCH_FIELD == "OBJECTID")
                        pQFilter.WhereClause = "OBJECTID = " + Junction_value;
                   
                    pFCursorJunc = null;
                    pFCursorJunc = pFClass_Junction.Search(pQFilter, true);
                    pFeatJunction = pFCursorJunc.NextFeature();
                    if (pFeatJunction == null)
                    {
                        WriteLine("No junction feature found for " + JUNCTION_SEARCH_FIELD + " = " + Junction_value);
                    }
                    while (pFeatJunction != null)
                    {
                        ((IWorkspaceEdit)pVersion).StartEditOperation();
                        junctionPoint = new PointClass();
                        junctionPoint = (ESRI.ArcGIS.Geometry.IPoint)pFeatJunction.ShapeCopy;
                        topologicalOerator = junctionPoint as ITopologicalOperator;
                        spatialFilter = new SpatialFilterClass();
                        spatialFilter.Geometry = junctionPoint as IGeometry;
                        spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                        // search in UG conductor
                        WriteLine("Finding OH Conductors intersecting this junction");
                        pFCursorLine = pFClass_PriUGCond.Search(spatialFilter, false);
                        while ((pFeatLine = pFCursorLine.NextFeature()) != null)
                        {
                            objectIdsLine.Add(Convert.ToDecimal(pFeatLine.get_Value(pFeatLine.Fields.FindField("OBJECTID"))));
                            intersectcount++;
                        }
                        traceFC = pFClass_PriUGCond;
                        WriteLine(intersectcount + " intersecting features found in UG Conductor");
                        if (intersectcount == 0)
                        {
                            // search in OH conductor 
                            WriteLine("Finding OH Conductors intersecting this junction");
                            pFCursorLine = pFClass_PriOHCond.Search(spatialFilter, false);
                            while ((pFeatLine = pFCursorLine.NextFeature()) != null)
                            {
                                objectIdsLine.Add(Convert.ToDecimal(pFeatLine.get_Value(pFeatLine.Fields.FindField("OBJECTID"))));
                                intersectcount++;
                            }
                            traceFC = pFClass_PriOHCond;
                            WriteLine(intersectcount + " intersecting features found in OH Conductor");
                            if (intersectcount == 0)
                                break;
                        }
                        try
                        {
                            matchingLine = 0;
                            tracecount = 0;
                            WriteLine("Tracing upstream from Junction");
                            pEnumEIDInfoLine = TraceUpstream(pFeatJunction, geomNet, TraceDirection.Upstream);
                            // WriteLine(pEnumEIDInfoLine.Count.ToString() + " traced results");
                            while ((pEIDInfo = pEnumEIDInfoLine.Next()) != null)
                            {
                                if (((IDataset)pEIDInfo.Feature.Class).Name == ((IDataset)traceFC).Name)
                                {
                                    tracecount++;
                                    try
                                    {
                                        pFeatLine = traceFC.GetFeature(pEIDInfo.Feature.OID);
                                        if (objectIdsLine.Contains(Convert.ToDecimal(pFeatLine.get_Value(pFeatLine.Fields.FindField("OBJECTID")))))
                                        {
                                            matchingLine++;
                                            populateConductorTieDTO(pFeatLine);
                                           
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        WriteLine(ex.Message);
                                    }
                                }
                            }
                            WriteLine(tracecount + " Pri Conductors found ");
                            
                            WriteLine("Creating Tie Feature");
                            pFeatTie = pFClass_Tie.CreateFeature();
                            // set shape
                            pFeatTie.Shape = junctionPoint;

                            // set default attributes
                            WriteLine("Setting default attributes.");
                            setTieAttributesDefault(pFeatTie);

                            //set attributes from configuration
                            WriteLine("Setting attributes from configuration.");
                            setTieAttributesFromConfiguration(pFeatTie, TIE_FIELDS_LIST_CSV_PATH);
                            
                            //set attributes from upstream connecting line.
                            WriteLine("Setting attibutes from feeding conductor.");
                            setTieAttributesFromLine(pFeatTie);
                            // Commit the new feature to the geodatabase.                            

                            pFeatTie.Store();
                            ((INetworkFeature)pFeatTie).Connect();
                            WriteLine("Tie feature successfully created.");
                            WriteLine("OBJECTID : " + pFeatTie.get_Value(pFClass_Tie.Fields.FindField("OBJECTID")));
                            WriteLine("GLOBALID : " + pFeatTie.get_Value(pFClass_Tie.Fields.FindField("GLOBALID")));
                            WriteLine("CREATIONUSER : " + pFeatTie.get_Value(pFClass_Tie.Fields.FindField("CREATIONUSER")));
                            WriteLine("DATECREATED : " + pFeatTie.get_Value(pFClass_Tie.Fields.FindField("DATECREATED")));
                            WriteLine("VERSIONNAME : " + pFeatTie.get_Value(pFClass_Tie.Fields.FindField("VERSIONNAME")));
                            pFeatJunction = pFCursorJunc.NextFeature();
                        }
                        catch (Exception ex)
                        {
                            WriteLine("ERROR: " + ex.Message);
                        }
                        finally
                        {
                            ((IWorkspaceEdit)pVersion).StopEditOperation();
                            if (pEIDInfo != null) Marshal.FinalReleaseComObject(pEIDInfo);
                            if (pEnumEIDInfoLine != null) Marshal.FinalReleaseComObject(pEnumEIDInfoLine);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                WriteLine("ERROR " + ex.Message);
            }
            finally
            {
                WriteLine("");
                WriteLine("Finally");
                if (pVersion != null) ((IWorkspaceEdit)pVersion).StopEditing(true);
                WriteLine("Editing stopped");
                m_AOLicenseInitializer.ShutdownApplication();
                GC.Collect();
                
                if (pVersion != null) Marshal.FinalReleaseComObject(pVersion);
                if (pFeatJunction != null) Marshal.FinalReleaseComObject(pFeatJunction);
                if (pFeatTie != null) Marshal.FinalReleaseComObject(pFeatTie);
                if (pFeatLine != null) Marshal.FinalReleaseComObject(pFeatLine);
                if (pFCursorLine != null) Marshal.FinalReleaseComObject(pFCursorLine);
                if (pFCursorJunc != null) Marshal.FinalReleaseComObject(pFCursorJunc);
                if (pQFilter != null) Marshal.FinalReleaseComObject(pQFilter);
                if (pFClass_Junction != null) Marshal.FinalReleaseComObject(pFClass_Junction);
                if (pFClass_Tie != null) Marshal.FinalReleaseComObject(pFClass_Tie);
                if (pFClass_PriOHCond != null) Marshal.FinalReleaseComObject(pFClass_PriOHCond);
                if (pFClass_PriUGCond != null) Marshal.FinalReleaseComObject(pFClass_PriUGCond);
                if (traceFC != null) Marshal.FinalReleaseComObject(traceFC);
                if (pEIDInfo != null) Marshal.FinalReleaseComObject(pEIDInfo);
                if (pEnumEIDInfoLine != null) Marshal.FinalReleaseComObject(pEnumEIDInfoLine);
                if (pEIDInfoTemp != null) Marshal.FinalReleaseComObject(pEIDInfoTemp);
                if (pEnumEIDInfoLineTemp != null) Marshal.FinalReleaseComObject(pEnumEIDInfoLineTemp);
                WriteLine("Resource Released");
                WriteLine("END");
            }
        }
        /// <summary>
        /// create log file 
        /// </summary>
        public static void createLogFile()
        {
            (pSWriter = File.CreateText(sPath)).Close();
        }
        /// <summary>
        /// Write on console and log file
        /// </summary>
        /// <param name="sMsg"></param>
        private static void WriteLine(string sMsg)
        {
            sMsg = !String.IsNullOrEmpty(sMsg) ? DateTime.Now.ToLongTimeString() + " -- " + sMsg : sMsg;
            pSWriter = File.AppendText(sPath);
            pSWriter.WriteLine(sMsg);
            Console.WriteLine(sMsg);
            pSWriter.Close();
        }
        /// <summary>
        /// Initialize licence
        /// </summary>
        private static void initializeLicence()
        {
            //ESRI License Initializer generated code.
            WriteLine("Initializing Licence");
            m_AOLicenseInitializer.InitializeApplication(new esriLicenseProductCode[] { esriLicenseProductCode.esriLicenseProductCodeBasic, esriLicenseProductCode.esriLicenseProductCodeStandard, esriLicenseProductCode.esriLicenseProductCodeAdvanced },
            new esriLicenseExtensionCode[] { });
            mmLicenseStatus licenseStatus = CheckOutLicenses(mmLicensedProductCode.mmLPArcFM);
            if (RuntimeManager.ActiveRuntime == null)
                RuntimeManager.BindLicense(ProductCode.Desktop);

        }
        /// <summary>
        /// get workspace from connection file
        /// </summary>
        /// <param name="connectionFile"></param>
        /// <returns></returns>
        private static IWorkspace ArcSdeWorkspaceFromFile(String connectionFile)
        {
            return ((IWorkspaceFactory)Activator.CreateInstance(Type.GetTypeFromProgID("esriDataSourcesGDB.SdeWorkspaceFactory"))).
                OpenFromFile(connectionFile, 0);
        }
        /// <summary>
        /// ArcFM Licence Initializer
        /// </summary>
        /// <param name="productCode">Code to checkout</param>
        /// <returns>Licence Status</returns>
        private static mmLicenseStatus CheckOutLicenses(mmLicensedProductCode productCode)
        {
            mmLicenseStatus licenseStatus;
            licenseStatus = arcFMAppInitialize.IsProductCodeAvailable(productCode);
            if (licenseStatus == mmLicenseStatus.mmLicenseAvailable)
            {
                licenseStatus = arcFMAppInitialize.Initialize(productCode);
            }
            return licenseStatus;
        }
        /// <summary>
        /// Popultate some fields in TieDTO with primary conductor fields obtained from traced results
        /// </summary>
        /// <param name="pFeatLine"></param>
        private static void populateConductorTieDTO(IFeature pFeatLine)
        {
            if (pFeatLine == null)
            {
                WriteLine("Feeding conductor not found.");
                return;
            }
            try
            {
                try
                {
                    
                    TieDTO.CIRCUITID = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("CIRCUITID")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting CIRCUITID field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.CIRCUITID2 = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("CIRCUITID2")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting CIRCUITID2 field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.CITY = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("CITY")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting CITY field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.COUNTY = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("COUNTY")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting COUNTY field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.CUSTOMEROWNED = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("CUSTOMEROWNED")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting CUSTOMEROWNED field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    if (pFeatLine.get_Value(traceFC.Fields.FindField("DISTRICT")) != DBNull.Value)
                        TieDTO.DISTRICT = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("DISTRICT")));
                    else
                        WriteLine("Value of DISTRICT is null in feeding conductor.");
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting DISTRICT field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    if (pFeatLine.get_Value(traceFC.Fields.FindField("DIVISION")) != DBNull.Value)
                        TieDTO.DIVISION = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("DIVISION")));
                    else
                        WriteLine("Value of DIVISION is null in feeding conductor.");
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting DIVISION field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    if (pFeatLine.get_Value(traceFC.Fields.FindField("FEEDERINFO")) != DBNull.Value)
                        TieDTO.FEEDERINFO = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("FEEDERINFO")));
                    else
                        WriteLine("Value of FEEDERINFO is null in feeding conductor.");

                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting FEEDERINFO field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    if (pFeatLine.get_Value(traceFC.Fields.FindField("FEEDERTYPE")) != DBNull.Value)
                        TieDTO.FEEDERTYPE = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("FEEDERTYPE")));
                    else
                        WriteLine("Value of FEEDERTYPE is null in feeding conductor.");
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting FEEDERTYPE field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.LOCALOFFICEID = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("LOCALOFFICEID")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting LOCALOFFICEID field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    if (pFeatLine.get_Value(traceFC.Fields.FindField("PHASEDESIGNATION")) != DBNull.Value)
                        TieDTO.PHASEDESIGNATION = Convert.ToDecimal(pFeatLine.get_Value(traceFC.Fields.FindField("PHASEDESIGNATION")));
                    else
                        WriteLine("Value of PHASEDESIGNATION is null in feeding conductor.");
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting PHASEDESIGNATION field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.PHASINGVERIFIEDSTATUS = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("PHASINGVERIFIEDSTATUS")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting PHASINGVERIFIEDSTATUS field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.REGION = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("REGION")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting REGION field from feeding conductor. MSG: " + ex.Message);
                }
                try
                {
                    TieDTO.ZIP = Convert.ToString(pFeatLine.get_Value(traceFC.Fields.FindField("ZIP")));
                }
                catch (Exception ex)
                {
                    WriteLine("Error in getting ZIP field from feeding conductor. MSG: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Set attributes in Conductor Tie (DATECREATED AND CREATIONDATE)
        /// </summary>
        /// <param name="tieFeature"></param>
        private static void setTieAttributesDefault(IFeature tieFeature)
        {
            try
            {
                TieDTO.DATECREATED = System.DateTime.Now;
                tieFeature.set_Value(pFClass_Tie.Fields.FindField("DATECREATED"), TieDTO.DATECREATED);
                WriteLine("DATECREATED = " + TieDTO.DATECREATED);
                TieDTO.DATEMODIFIED = System.DateTime.Now;
                tieFeature.set_Value(pFClass_Tie.Fields.FindField("DATEMODIFIED"), TieDTO.DATEMODIFIED);
                WriteLine("DATEMODIFIED = " + TieDTO.DATEMODIFIED);
                TieDTO.CREATIONUSER = System.Environment.UserName;
                tieFeature.set_Value(pFClass_Tie.Fields.FindField("CREATIONUSER"), TieDTO.CREATIONUSER);
                WriteLine("CREATIONUSER = " + TieDTO.CREATIONUSER);
                TieDTO.LASTUSER = System.Environment.UserName;
                tieFeature.set_Value(pFClass_Tie.Fields.FindField("LASTUSER"), TieDTO.LASTUSER);
                WriteLine("LASTUSER = " + TieDTO.LASTUSER);
                
            }
            catch (Exception ex)
            {
                WriteLine("Error in setting default values ");
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Set attributes in Conductor Tie (Attribute values retrieved from Configuration)
        /// </summary>
        /// <param name="tieFeature"></param>
        private static void setTieAttributesFromConfiguration(IFeature tieFeature, string TIE_FIELDS_LIST_CSV_PATH)
        {
            try
            {
                var reader = new StreamReader(File.OpenRead(TIE_FIELDS_LIST_CSV_PATH));
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    string CTfield = values[0].ToString();
                    string CTvalue = values[1].ToString();
                    tieFeature.set_Value(pFClass_Tie.Fields.FindField(CTfield), CTvalue);
                    WriteLine(CTfield + " = " + CTvalue);
                }
            }
            catch (Exception ex)
            {
                WriteLine("Error in updating default values from path " + TIE_FIELDS_LIST_CSV_PATH);
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Set attributes in Conductor Tie (Attribute values retrieved from Upstream conductor)
        /// </summary>
        /// <param name="tieFeature"></param>
        private static void setTieAttributesFromLine(IFeature tieFeature)
        {
            try
            {
                tieFeature.set_Value(pFClass_Tie.FindField("CIRCUITID"), TieDTO.CIRCUITID);
                WriteLine("CIRCUITID = " + TieDTO.CIRCUITID.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("CIRCUITID2"), TieDTO.CIRCUITID2);
                WriteLine("CIRCUITID2 = " + TieDTO.CIRCUITID2.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("CITY"), TieDTO.CITY);
                WriteLine("CITY = " + TieDTO.CITY.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("COUNTY"), TieDTO.COUNTY);
                WriteLine("COUNTY = " + TieDTO.COUNTY.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("CUSTOMEROWNED"), TieDTO.CUSTOMEROWNED);
                WriteLine("CUSTOMEROWNED = " + TieDTO.CUSTOMEROWNED.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("DISTRICT"), TieDTO.DISTRICT);
                WriteLine("DISTRICT = " + TieDTO.DISTRICT.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("DIVISION"), TieDTO.DIVISION);
                WriteLine("DIVISION = " + TieDTO.DIVISION.ToString());
                //tieFeature.set_Value(pFClass_Tie.FindField("ELECTRICTRACEWEIGHT"), TieDTO.ELECTRICTRACEWEIGHT);
                //WriteLine("ELECTRICTRACEWEIGHT = " + TieDTO.ELECTRICTRACEWEIGHT.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("FEEDERINFO"), TieDTO.FEEDERINFO);
                WriteLine("FEEDERINFO = " + TieDTO.FEEDERINFO.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("FEEDERTYPE"), TieDTO.FEEDERTYPE);
                WriteLine("FEEDERTYPE = " + TieDTO.FEEDERTYPE.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("LOCALOFFICEID"), TieDTO.LOCALOFFICEID);
                WriteLine("LOCALOFFICEID = " + TieDTO.LOCALOFFICEID.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("PHASEDESIGNATION"), TieDTO.PHASEDESIGNATION);
                WriteLine("PHASEDESIGNATION = " + TieDTO.PHASEDESIGNATION.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("PHASINGVERIFIEDSTATUS"), TieDTO.PHASINGVERIFIEDSTATUS);
                WriteLine("PHASEVERIFIEDSTATUS = " + TieDTO.PHASINGVERIFIEDSTATUS.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("REGION"), TieDTO.REGION);
                WriteLine("REGION = " + TieDTO.REGION.ToString());
                tieFeature.set_Value(pFClass_Tie.FindField("ZIP"), TieDTO.ZIP);
            }
            catch (Exception ex)
            {
                WriteLine("Error in setting value in Tie feature from feeding conductor. " + ex.Message);
            }
        }
        /// <summary>
        /// To get upstream trace results
        /// </summary>
        /// <param name="pFeat_Start"></param>
        /// <param name="geomNet"></param>
        /// <param name="tracedirection"></param>
        /// <returns></returns>
        private static IEnumEIDInfo TraceUpstream(IFeature pFeat_Start, IGeometricNetwork geomNet, TraceDirection tracedirection)
        {
            WriteLine("Trace Args - ");
            WriteLine("Feature Class: " + pFeat_Start.Class.AliasName.ToString());
            WriteLine("OID: " + pFeat_Start.OID.ToString());
            WriteLine("Geometric network: " + geomNet.FeatureDataset.BrowseName.ToString());
            WriteLine("Trace Direction: " + tracedirection);
            IMMElectricNetworkTracing elecNetTracing = new MMFeederTracerClass();
            IMMElectricTraceSettingsEx elecTraceSettingsEx = default(IMMElectricTraceSettingsEx);
            IEnumNetEID juncEIDs = default(IEnumNetEID);
            IEnumNetEID edgeEIDs = default(IEnumNetEID);
            IMMNetworkAnalysisExtForFramework MMNetAnalExtForFramework = new MMNetworkAnalysisExtForFrameworkClass();
            IMMElectricTraceSettings elecTraceSetttings = new MMElectricTraceSettings();
            IEnumEIDInfo pEnumEIDInfo = default(IEnumEIDInfo);
            IEIDHelper pEIDHelper = default(IEIDHelper);
            try
            {
                elecTraceSetttings.RespectConductorPhasing = true;
                elecTraceSetttings.RespectEnabledField = true;
                elecTraceSettingsEx = (IMMElectricTraceSettingsEx)elecTraceSetttings;
                elecTraceSettingsEx.UseFeederManagerCircuitSources = true;
                elecTraceSettingsEx.RespectESRIBarriers = true;
                elecNetTracing.TraceUpstream(geomNet, MMNetAnalExtForFramework, elecTraceSettingsEx, (pFeat_Start.Shape.GeometryType == esriGeometryType.esriGeometryPoint) ? ((ISimpleJunctionFeature)pFeat_Start).EID : ((ISimpleEdgeFeature)pFeat_Start).EID,
                        ((pFeat_Start.Shape.GeometryType == esriGeometryType.esriGeometryPoint) ? esriElementType.esriETJunction : esriElementType.esriETEdge),
                        mmPhasesToTrace.mmPTT_Any, out juncEIDs, out edgeEIDs);
                pEIDHelper = new EIDHelperClass()
                {
                    GeometricNetwork = geomNet,
                    ReturnGeometries = true,
                    ReturnFeatures = true
                };
                pEnumEIDInfo = pEIDHelper.CreateEnumEIDInfo(edgeEIDs);
            }
            catch (Exception ex)
            {
                WriteLine("Error in Upstream Trace : " + ex.Message);
            }
            finally
            {
                if (elecNetTracing != null) Marshal.FinalReleaseComObject(elecNetTracing);
                if (elecTraceSettingsEx != null) Marshal.FinalReleaseComObject(elecTraceSettingsEx);
                if (juncEIDs != null) Marshal.FinalReleaseComObject(juncEIDs);
                if (edgeEIDs != null) Marshal.FinalReleaseComObject(edgeEIDs);
                if (MMNetAnalExtForFramework != null) Marshal.FinalReleaseComObject(MMNetAnalExtForFramework);
                if (elecTraceSetttings != null) Marshal.FinalReleaseComObject(elecTraceSetttings);
                if (pEIDHelper != null) Marshal.FinalReleaseComObject(pEIDHelper);
                // if (pEnumEIDInfo != null) Marshal.FinalReleaseComObject(pEnumEIDInfo);

            }
            return pEnumEIDInfo;
        }

    }

}
