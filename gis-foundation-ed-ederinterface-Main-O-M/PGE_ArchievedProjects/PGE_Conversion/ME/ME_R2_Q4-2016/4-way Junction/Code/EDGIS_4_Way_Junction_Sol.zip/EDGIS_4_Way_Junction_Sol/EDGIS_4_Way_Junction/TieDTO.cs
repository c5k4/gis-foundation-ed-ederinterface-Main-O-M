﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EDGIS_4_Way_Junction
{
    public static class TieDTO
    {
        public static string abc;

        public static string OBJECTID;
        public static decimal ANCILLARYROLE;
        public static decimal ENABLED;
        public static string GLOBALID;
        public static string CREATIONUSER;
        public static DateTime DATECREATED;
        public static DateTime DATEMODIFIED;
        public static string LASTUSER;
        public static decimal CONVERSIONID;
        public static string CONVERSIONWORKPACKAGE;
        public static decimal STATUS;
        public static decimal ELECTRICTRACEWEIGHT;
        public static string CIRCUITID;
        public static string CIRCUITID2;
        public static string CONVCIRCUITID;
        public static string CONVCIRCUITID2;
        public static decimal FEEDERINFO;
        public static DateTime INSTALLATIONDATE;
        public static DateTime RETIREDATE;
        public static decimal NUMBEROFPHASES;
        public static decimal PHASEDESIGNATION;
        public static string PHASINGVERIFIEDSTATUS;
        public static decimal SYMBOLROTATION;
        public static string INSTALLJOBPREFIX;
        public static decimal INSTALLJOBYEAR;
        public static string COMMENTS;
        public static decimal CEDSADEVICEID;
        public static string LOCALOPOFFICE;
        public static string SOURCESIDEDEVICEID;
        public static string COMPLEXDEVICEIDC;
        public static string CUSTOMEROWNED;
        public static decimal SYMBOLNUMBER;
        public static string LOCDESC;
        public static decimal COUNTY;
        public static string ZIP;
        public static string GEMSDISTMAPNUM;
        public static string GEMSCIRCUITMAPNUM;
        public static string GEMSOTHERMAPNUM;
        public static string ANIMALGUARDTYPE;
        public static decimal DIVISION;
        public static decimal DISTRICT;
        public static string VAULT;
        public static string REPLACEGUID;
        public static decimal SUBTYPECD;
        public static string INSTALLATIONTYPE;
        public static string LOCALOFFICEID;
        public static string REGION;
        public static string INSTALLJOBNUMBER;
        public static string CITY;
        public static string VERSIONNAME;
        //ST_GEOMETRY	SHAPE
        public static string PROTECTIVESSD;
        public static string AUTOPROTECTIVESSD;
        public static decimal FEEDERTYPE;
        public static string SSDGUID;

    }
}
