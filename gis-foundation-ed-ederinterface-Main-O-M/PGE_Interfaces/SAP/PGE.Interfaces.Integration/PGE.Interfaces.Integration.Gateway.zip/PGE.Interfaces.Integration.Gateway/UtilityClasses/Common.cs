﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ESRI.ArcGIS.Geodatabase;

namespace PGE.Interfaces.Integration.Gateway
{
    public class Common
    {
        #region Private variable 
        public static  Log4NetLogger _log = new Log4NetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "pge.log4net.config" );
        #endregion

        #region Public variable 
        #endregion

        #region Private Methods 
        #endregion

        #region Public Methods 
        /// <summary>
        /// 
        /// </summary>
        /// <param name="argStrworkSpaceConnectionstring"></param>
        /// <returns></returns>
        public IWorkspace GetWorkspace(string argStrworkSpaceConnectionstring)
        {
            Type t = null;
            IWorkspaceFactory workspaceFactory = null;
            IWorkspace workspace = null;
            try
            {

                t = Type.GetTypeFromProgID("esriDataSourcesGDB.SdeWorkspaceFactory");
                workspaceFactory = (IWorkspaceFactory)Activator.CreateInstance(t);
                workspace = workspaceFactory.OpenFromFile(argStrworkSpaceConnectionstring, 0);
            }
            catch (Exception exp)
            {
                Common._log.Error("Error in getting SDE Workspace, function GetWorkspace: " + exp.Message);
                Common._log.Info(exp.Message + "   " + exp.StackTrace);
                throw exp;
            }
            return workspace;
        }
        #endregion

    }
}
