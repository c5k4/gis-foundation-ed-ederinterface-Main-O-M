﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ESRI.ArcGIS.Geodatabase;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Timers;

namespace PGE.Interfaces.Integration.Gateway
{
    class MainClass
    {

        public static DateTime m_dStartTime;
        private PullData pullDataObject=null ;
      
        internal bool StartProcess()
        {             
             IWorkspace m_SDEEDERDefaultworkspace = null;             
            
            bool ProcessCompleted = false;
            try
            {
                pullDataObject = new PullData();
                pullDataObject.CreateWebRequest();
                ProcessCompleted = true;
            }
            catch (Exception exp)
            {
                Common._log.Error(exp.Message + " at " + exp.StackTrace);
                ErrorCodeException ece = new ErrorCodeException(exp);
                Environment.ExitCode = ece.CodeNumber;
            }
            finally 
            {
                if (m_SDEEDERDefaultworkspace != null) { Marshal.ReleaseComObject(m_SDEEDERDefaultworkspace); m_SDEEDERDefaultworkspace = null; }               
              
            }
            return ProcessCompleted;
        }

        void TimerTick(System.Object obj, ElapsedEventArgs e)
        {

            Common._log.Error("");
            Common._log.Error("");
            Environment.Exit(0);
            
        }


        
    }
}
