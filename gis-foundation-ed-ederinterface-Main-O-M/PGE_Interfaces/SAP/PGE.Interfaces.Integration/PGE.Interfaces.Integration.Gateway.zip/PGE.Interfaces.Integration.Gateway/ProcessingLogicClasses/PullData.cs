﻿using System;
using System.Net;
using System.Data;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Net.Http;

using Newtonsoft.Json.Linq;

namespace PGE.Interfaces.Integration.Gateway
{
   public class PullData
    {
        #region public Variables

        public ED07Data dataBlock;
        #endregion 
        /// <summary>
        /// This method is used to create webrequest  
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable CreateWebRequest()
        {
            DataTable dtJson = null ;
            try
            {

                //using (var client = new HttpClient())
                //{
                //    var json = await client.GetStringAsync("https://api-d.cloud.pge.com/Electric/v1/ElectricDistribution/ED07Set?$filter=RequestDate eq '20210203' and BatchId eq ' '&$format=json");
                //    var odata = JsonConvert.DeserializeObject<OData>(json);
                //}

                //using (var client = new HttpClient())
                //{
                //    HttpResponseMessage response1 = await client.GetAsync(new Uri("https://api-d.cloud.pge.com/Electric/v1/ElectricDistribution/ED07Set?$filter=RequestDate eq '20210203' and BatchId eq ' '&$format=json"));
                //    var json = await response.Content.ReadAsStringAsync();
                //    var result = JsonConvert.DeserializeObject<ODataResponse<Product>>(json);
                //    var products = result.Value;
                //}
                    //Create WebRequest
                    HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create("https://api-d.cloud.pge.com/Electric/v1/ElectricDistribution/ED07Set?$filter=RequestDate eq '20210203' and BatchId eq ' '&$format=json");
               Common._log.Info("Web Request Created");                
                
                webRequest.Method = "GET";
                webRequest.ContentType = "application/json";   
                webRequest.AutomaticDecompression = DecompressionMethods.GZip;             

                HttpWebResponse response = null;
                
                //Get Response from web Request
                using (response = (HttpWebResponse)webRequest.GetResponse())

                // Get Response  stream from  Response
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    var html = reader.ReadToEnd();
                    //Console.WriteLine(html);
                    Common._log.Info(html);
                    bool isContainError = html.Contains("error");
               //     Console.WriteLine("Error in Reponse:=  " + isContainError);
               //     Common._log.Info("Error in Reponse:=  " + isContainError);
                    if (isContainError)
                        return dtJson;
                    Common._log.Info("Web Response received");
                    // Deserialize HttpWebResponse                   
                  //  var x= JsonConvert.DeserializeObject(html);

                  //  dynamic dynamicObject = JsonConvert.DeserializeObject(html);
                  //  foreach (var s in dynamicObject )
                  //  {
                  //      Console.WriteLine(s._metadata);
                  //  }
                  //  //string type = dynamicObject.;

                  //  var jsonLinq = JObject.Parse(html);
                  //  // Find the first array using Linq
                  ////  var srcArray = jsonLinq.Descendants().Children(d => d is JArray).First();
                  //  var trgArray = new JArray();

                  //  dtJson = (DataTable)JsonConvert.DeserializeObject(html, (typeof(DataTable)));
                    dataBlock = JsonConvert.DeserializeObject<ED07Data>(html);
                    
                    DataSet JSONDataset = JsonConvert.DeserializeObject<DataSet>(html);
                   
                   // dtJson = (DataTable)JsonConvert.DeserializeObject(html);
                    Common._log.Info(" Web Response received:" + html);
                }
            }
            catch (Exception ex) 
            {

            }
            return dtJson;
        }

        private void InsertRow(ED07Record row)
        {
            try
            {
                if (row == null) return;

                //Writes the values to IRow
                //_logger.Info("Inserted New Record");
                //WriteFieldValues(newRow, row);
                //newRow.Store();
            }
            catch (Exception ex)
            {
               // _logger.Error("Error inserting row.", ex);
            }
        }

    }
}
